declare class Helper {
  public uuid: string
  public title: string
  // 男生|女生|不限
  public gender: string
  public content: string
  public tips: string
  public deadline: Date
  public commission: number
}